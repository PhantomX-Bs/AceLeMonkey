
const backgrounds = [
    'url("https://images.unsplash.com/photo-1502082553048-f009c37129b9")',
    'url("https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13")',
    'url("https://images.unsplash.com/photo-1508675801605-43d0f06c2062")'
];

function changeBackground(index) {
    document.querySelector('.container').style.backgroundImage = backgrounds[index];
}

// Initial background
changeBackground(0);
